#!/bin/bash
# My first script

python server.py